import tkinter as tk
import random

def change_color():
    # Renkleri hızlıca rastgele değiştir
    color = random.choice(["red", "blue", "green", "yellow", "purple", "cyan", "magenta", "orange"])
    root.configure(bg=color)
    root.after(50, change_color)  # 50 milisaniyede bir renk değiştir

def close(event):
    # "W" tuşuna basılırsa pencereyi kapat
    if event.char == 'w':
        root.destroy()

# Ana pencereyi oluştur
root = tk.Tk()
root.title("Şaka Virüsü!")
root.attributes("-fullscreen", True)  # Tam ekran yap
root.bind("<Key>", close)  # Klavye girişini dinle, yalnızca 'w' kapatır
change_color()  # Renk döngüsünü başlat

# Döngüyü başlat
root.mainloop()